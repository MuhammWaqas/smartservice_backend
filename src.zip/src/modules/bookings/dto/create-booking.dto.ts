// src/modules/bookings/dto/create-booking.dto.ts
import { IsNotEmpty, IsDateString, IsNumber, IsOptional } from 'class-validator';

export class CreateBookingDto {
  @IsNotEmpty()
  service_id: string;

  @IsNotEmpty()
  slug: string;

  @IsDateString()
  date: string;

  @IsNotEmpty()
  time: string;

  @IsNotEmpty()
  @IsNumber()
  total_amount: number;

  @IsOptional()
  address?: {
    street?: string;
    city?: string;
    state?: string;
    zip?: string;
    lat?: number;
    lng?: number;
  };
}

