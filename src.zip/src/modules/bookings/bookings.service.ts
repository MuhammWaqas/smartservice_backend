// src/modules/bookings/bookings.service.ts
import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Types } from 'mongoose';
import { Booking, BookingDocument } from './schemas/booking.schema';
import { Service, ServiceDocument } from '../services/schemas/service.schema';
import { CreateBookingDto } from './dto/create-booking.dto';
import { UpdateBookingDto } from './dto/update-booking.dto';

@Injectable()
export class BookingsService {
  constructor(
    @InjectModel(Booking.name) private bookingModel: Model<BookingDocument>,
    @InjectModel(Service.name) private serviceModel: Model<ServiceDocument>,
  ) { }

  // async create(createBookingDto: CreateBookingDto, user: any): Promise<Booking> {
  //   const booking = new this.bookingModel(createBookingDto);
  //   return booking.save();
  // }

  async create(dto: CreateBookingDto, user: any) {

    const service = await this.serviceModel.findById(dto.service_id);

    if (!service) {
      throw new NotFoundException('Service not found');
    }

    const booking = new this.bookingModel({
      slug: dto.slug,
      date: dto.date,
      time: dto.time,
      total_amount: dto.total_amount,
      address: dto.address,

      user_id: new Types.ObjectId(user._id),              //  JWT
      service_id: new Types.ObjectId(dto.service_id),     //  convert
      provider_id: new Types.ObjectId(service.provider),  //  auto

      status: 'pending',
    });

    return booking.save();
  }

  async findAll(user: any): Promise<Booking[]> {
    // Role-based fetch
    if (user.role === 'admin') return this.bookingModel.find().populate('user_id service_id provider_id').exec();
    if (user.role === 'provider') return this.bookingModel.find({ provider_id: user._id }).populate('user_id service_id').exec();
    return this.bookingModel.find({ user_id: user._id }).populate('service_id provider_id').exec();
  }

  async findOne(id: string, user: any): Promise<Booking> {
    const booking = await this.bookingModel.findById(id).populate('user_id service_id provider_id').exec();
    if (!booking) throw new NotFoundException('Booking not found');
    // User can access only own booking
    if (user.role === 'user' && booking.user_id._id.toString() !== user._id) throw new ForbiddenException();
    if (user.role === 'provider' && booking.provider_id._id.toString() !== user._id) throw new ForbiddenException();
    return booking;
  }

  async update(id: string, updateBookingDto: UpdateBookingDto, user: any): Promise<Booking> {
    const booking = await this.bookingModel.findById(id);
    if (!booking) throw new NotFoundException('Booking not found');
    // Only provider/admin can update status
    if (user.role === 'user') throw new ForbiddenException();
    if (updateBookingDto.status) booking.status = updateBookingDto.status;
    return booking.save();
  }

  async remove(id: string, user: any): Promise<any> {
    const booking = await this.bookingModel.findById(id);

    if (!booking) {
      throw new NotFoundException('Booking not found');
    }

    // Only admin or owner can delete
    if (user.role === 'user' && booking.user_id.toString() !== user._id) {
      throw new ForbiddenException();
    }

    await booking.deleteOne();

    return {
      message: 'Booking deleted successfully',
    };
  }

}
